package com.soems.dto;

public class RegistrationDTO {

    private Long id;
    private String registerDate;
    private String eventTitle;
    private String eventLocation;
    private String userName;
    private String userEmail;

    public RegistrationDTO(Long id, String registerDate, String eventTitle,
                            String eventLocation, String userName, String userEmail) {
        this.id = id;
        this.registerDate = registerDate;
        this.eventTitle = eventTitle;
        this.eventLocation = eventLocation;
        this.userName = userName;
        this.userEmail = userEmail;
    }

    public Long getId() {
        return id;
    }

    public String getRegisterDate() {
        return registerDate;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserEmail() {
        return userEmail;
    }
}
