package com.soems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.soems.dto.RegistrationDTO;
import com.soems.entity.Registration;
import com.soems.service.RegistrationService;

@RestController
@RequestMapping("/registrations")
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService;
    
    // CREATE Event
    @PostMapping
    public String createRegistration(@RequestBody Registration registration) {
        return registrationService.createRegistration(registration);
    }

    // READ All Events
    @GetMapping
    public List<Registration> getAllRegistrations() {
        return registrationService.getAllRegistrations();
    }

    // READ Event by ID
    @GetMapping("/{id}")
    public Registration getRegistration(@PathVariable Long id) {
        return registrationService.getRegistrationById(id);
    }

    // UPDATE Event
    @PutMapping("/{id}")
    public String updateRegistration(@PathVariable Long id, @RequestBody Registration registration) {
    	registration.setId(id);
        return registrationService.updateRegistration(registration);
    }

    // DELETE Event
    @DeleteMapping("/{id}")
    public String deleteRegistration(@PathVariable Long id) {
        return registrationService.deleteRegistration(id);
    }
    
    // Get all registrations for a specific event
    @GetMapping("/event/{eventId}")
    public List<RegistrationDTO> getRegistrationsByEvent(@PathVariable Long eventId) {
        return registrationService.getRegistrationsForEvent(eventId);
    }

    // Get all registrations for a specific user
    @GetMapping("/user/{userId}")
    public List<RegistrationDTO> getRegistrationsByUser(@PathVariable Long userId) {
        return registrationService.getRegistrationsForUser(userId);
    }
}
