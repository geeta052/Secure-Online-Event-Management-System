package com.soems.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.soems.entity.User;

@Repository
public class userDAOImpl implements UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void save(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
	}

	@Override
	public User findByEmail(String email) {
		return sessionFactory.getCurrentSession()
                .createQuery("from User where email=:email", User.class)
                .setParameter("email", email)
                .uniqueResult();
	}

	@Override
	public User findById(Long id) {
		return sessionFactory.getCurrentSession().get(User.class, id);
	}

	@Override
	public List<User> findAll() {
		return sessionFactory.getCurrentSession()
				.createQuery("from User", User.class)
				.getResultList();
	}

	@Override
	public void update(User user) {
		sessionFactory.getCurrentSession().update(user);
	}

	@Override
	public void delete(Long id) {
		User u = findById(id);
		if (u != null) {
			sessionFactory.getCurrentSession().delete(u);
		}
	}
}
