package com.soems.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soems.dao.EventDAO;
import com.soems.entity.Event;

@Service
@Transactional
public class EventServiceImpl implements EventService {

    @Autowired
    private EventDAO eventDAO;

    @Override
    public String createEvent(Event event) {
        eventDAO.save(event);
        return "Event created successfully!";
    }

    @Override
    public Event getEventById(Long id) {
        return eventDAO.findById(id);
    }

    @Override
    public List<Event> getAllEvents() {
        return eventDAO.findAll();
    }

    @Override
    public String updateEvent(Event event) {
        eventDAO.update(event);
        return "Event updated successfully!";
    }

    @Override
    public String deleteEvent(Long id) {
        eventDAO.delete(id);
        return "Event deleted successfully!";
    }
}
