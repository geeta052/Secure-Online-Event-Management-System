package com.soems.service;

import java.util.List;
import com.soems.entity.Event;

public interface EventService {
    String createEvent(Event event);
    Event getEventById(Long id);
    List<Event> getAllEvents();
    String updateEvent(Event event);
    String deleteEvent(Long id);
}
