package com.soems.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.soems.dao.UserDAO;
import com.soems.entity.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDAO userDao;
	
	private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

	@Override
	public String registerUser(User user) { 
		if(userDao.findByEmail(user.getEmail()) != null) {
			return "Email already exists!";
		}
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		userDao.save(user);
		return "User registered successfully!";
	}

	@Override 
	public String loginUser(String email, String password) {
		User exist = userDao.findByEmail(email);
		if(exist != null && passwordEncoder.matches(password, exist.getPassword())) {
			return "Login Successful!";
		}
		return "Invalid email or password!";
	}

	@Override
	public User getUserById(Long id) {
		return userDao.findById(id);
	}

	@Override
	public List<User> getAllUsers() {
		return userDao.findAll();
	}

	@Override
	public String updateUser(User user) {
		userDao.update(user);
		return "User updated successfully!";
	}

	@Override
	public String deleteUser(Long id) {
		userDao.delete(id);
		return "User deleted successfully!";
	}
}
