package com.soems.service;

import com.soems.entity.User;
import java.util.List;

public interface UserService {
    String registerUser(User user);
    String loginUser(String email, String password);
    User getUserById(Long id);
    List<User> getAllUsers();
    String updateUser(User user);
    String deleteUser(Long id);
}
