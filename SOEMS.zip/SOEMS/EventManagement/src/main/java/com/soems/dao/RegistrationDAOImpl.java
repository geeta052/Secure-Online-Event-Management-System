package com.soems.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.soems.entity.Registration;

@Repository
public class RegistrationDAOImpl implements RegistrationDAO {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void save(Registration registration) {
        Session session = sessionFactory.getCurrentSession();
        session.save(registration);
    }

    @Override
    public Registration findById(Long id) {
        return sessionFactory.getCurrentSession().get(Registration.class, id);
    }

    @Override
    public List<Registration> findAll() {
        return sessionFactory.getCurrentSession()
                .createQuery("from Registration", Registration.class)
                .getResultList();
    }

    @Override
    public void update(Registration registration) {
        sessionFactory.getCurrentSession().update(registration);
    }

    @Override
    public void delete(Long id) {
    	Registration reg = findById(id);
        if (reg != null) {
            sessionFactory.getCurrentSession().delete(reg);
        }
    }
    
//    @Override
//    public List<Registration> getByEventId(Long eventId) {
//        return sessionFactory.getCurrentSession()
//                .createQuery("from Registration r where r.event.eventId = :eventId", Registration.class)
//                .setParameter("eventId", eventId)
//                .getResultList();
//    }
//    
//    @Override
//    public List<Registration> getByUserId(Long userId) {
//        return sessionFactory.getCurrentSession()
//                .createQuery("from Registration r where r.user.id = :userId", Registration.class)
//                .setParameter("userId", userId)
//                .getResultList();
//    }
    
    @Override
    public List<Registration> getByEventId(Long eventId) {
        return sessionFactory.getCurrentSession()
                .createQuery(
                    "SELECT r FROM Registration r " +
                    "JOIN FETCH r.user u " +
                    "JOIN FETCH r.event e " +
                    "WHERE e.eventId = :eventId",
                    Registration.class
                )
                .setParameter("eventId", eventId)
                .getResultList();
    }

    @Override
    public List<Registration> getByUserId(Long userId) {
        return sessionFactory.getCurrentSession()
                .createQuery(
                    "SELECT r FROM Registration r " +
                    "JOIN FETCH r.event e " +
                    "JOIN FETCH r.user u " +
                    "WHERE u.id = :userId",
                    Registration.class
                )
                .setParameter("userId", userId)
                .getResultList();
    }

}
