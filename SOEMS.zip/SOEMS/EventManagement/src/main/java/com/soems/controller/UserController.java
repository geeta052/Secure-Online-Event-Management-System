package com.soems.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.soems.entity.User;
import com.soems.service.UserService;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    @ResponseBody
    public User getUser(@PathVariable Long id) {
        return userService.getUserById(id);
    }

    @GetMapping
    @ResponseBody
    public List<User> listUsers() {
        return userService.getAllUsers();
    }

    @PostMapping("/update")
    @ResponseBody
    public String updateUser(@ModelAttribute User user) {
        return userService.updateUser(user);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    public String deleteUser(@PathVariable Long id) {
        return userService.deleteUser(id);
    }
}
