package com.soems.service;

import java.util.List;

import com.soems.dto.RegistrationDTO;
import com.soems.entity.Registration;

public interface RegistrationService {
    String createRegistration(Registration registration);
    Registration getRegistrationById(Long id);
    List<Registration> getAllRegistrations();
    String updateRegistration(Registration registration);
    String deleteRegistration(Long id);
    
    List<RegistrationDTO> getRegistrationsForEvent(Long eventId);
    List<RegistrationDTO> getRegistrationsForUser(Long userId);
}
