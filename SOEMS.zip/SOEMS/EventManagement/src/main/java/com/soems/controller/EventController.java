package com.soems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.soems.entity.Event;
import com.soems.service.EventService;

@RestController
@RequestMapping("/events")
public class EventController {

    @Autowired
    private EventService eventService;

    // CREATE Event
    @PostMapping
    public String createEvent(@RequestBody Event event) {
        return eventService.createEvent(event);
    }

    // READ All Events
    @GetMapping
    public List<Event> getAllEvents() {
        return eventService.getAllEvents();
    }

    // READ Event by ID
    @GetMapping("/{id}")
    public Event getEvent(@PathVariable Long id) {
        return eventService.getEventById(id);
    }

    // UPDATE Event
    @PutMapping("/{id}")
    public String updateEvent(@PathVariable Long id, @RequestBody Event event) {
        event.setEventId(id); // ensure ID is set for update
        return eventService.updateEvent(event);
    }

    // DELETE Event
    @DeleteMapping("/{id}")
    public String deleteEvent(@PathVariable Long id) {
        return eventService.deleteEvent(id);
    }
}
