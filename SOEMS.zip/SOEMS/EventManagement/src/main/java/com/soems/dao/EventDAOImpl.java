package com.soems.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.soems.entity.Event;

@Repository
public class EventDAOImpl implements EventDAO {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void save(Event event) {
        Session session = sessionFactory.getCurrentSession();
        session.save(event);
    }

    @Override
    public Event findById(Long id) {
        return sessionFactory.getCurrentSession().get(Event.class, id);
    }

    @Override
    public List<Event> findAll() {
        return sessionFactory.getCurrentSession()
                .createQuery("from Event", Event.class)
                .getResultList();
    }

    @Override
    public void update(Event event) {
        sessionFactory.getCurrentSession().update(event);
    }

    @Override
    public void delete(Long id) {
        Event ev = findById(id);
        if (ev != null) {
            sessionFactory.getCurrentSession().delete(ev);
        }
    }
}
