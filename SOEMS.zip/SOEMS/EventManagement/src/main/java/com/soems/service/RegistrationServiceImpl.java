package com.soems.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soems.dao.RegistrationDAO;
import com.soems.dto.RegistrationDTO;
import com.soems.entity.Registration;

@Service
@Transactional
public class RegistrationServiceImpl implements RegistrationService {

    @Autowired
    private RegistrationDAO registrationDAO;

    @Override
    public String createRegistration(Registration registration) {
    	registrationDAO.save(registration);
        return "Registration created successfully!";
    }

    @Override
    public Registration getRegistrationById(Long id) {
        return registrationDAO.findById(id);
    }

    @Override
    public List<Registration> getAllRegistrations() {
        return registrationDAO.findAll();
    }

    @Override
    public String updateRegistration(Registration registration) {
    	registrationDAO.update(registration);
        return "Registration updated successfully!";
    }

    @Override
    public String deleteRegistration(Long id) {
    	registrationDAO.delete(id);
        return "Registration deleted successfully!";
    }
    
    @Override
    public List<RegistrationDTO> getRegistrationsForEvent(Long eventId) {
        return registrationDAO.getByEventId(eventId).stream()
            .map(r -> new RegistrationDTO(
                r.getId(),
                r.getRegisterDate().toString(),
                r.getEvent().getEventName(),
                r.getEvent().getLocation(),
                r.getUser().getUsername(),
                r.getUser().getEmail()
            ))
            .collect(Collectors.toList());
    }

    @Override
    public List<RegistrationDTO> getRegistrationsForUser(Long userId) {
        return registrationDAO.getByUserId(userId).stream()
            .map(r -> new RegistrationDTO(
                r.getId(),
                r.getRegisterDate().toString(),
                r.getEvent().getEventName(),
                r.getEvent().getLocation(),
                r.getUser().getUsername(),
                r.getUser().getEmail()
            ))
            .collect(Collectors.toList());
    }

    
//    @Override
//    public List<Registration> getRegistrationsForEvent(Long eventId) {
//        return registrationDAO.getByEventId(eventId);
//    }
//
//    @Override
//    public List<Registration> getRegistrationsForUser(Long userId) {
//        return registrationDAO.getByUserId(userId);
//    }
}
