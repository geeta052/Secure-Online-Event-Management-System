package com.soems.entity;
 
import javax.persistence.*;
 
@Entity
@Table(name = "payments")
public class Payment {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
 
    @OneToOne
    @JoinColumn(name = "registration_id")
    private Registration registration;
 
    @Column(nullable = false)
    private double amount;
 
    @Column(nullable = false)
    private String paymentDate;
 
    public enum PaymentStatus {
        PAID,
        FAILED
    }
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
	private PaymentStatus paymentStatus; // e.g., PAID, FAILED

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}
    
}