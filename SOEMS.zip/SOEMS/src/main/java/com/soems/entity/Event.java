package com.soems.entity;
 
 
 
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;
 
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
 
// Remove @ValidEventDates and all JSR-303 annotations
@Entity
@Table(name = "events")
public class Event {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long eventId;
 
    @Column(nullable = false, length = 100)
    private String eventName;
 
    @Column
    private String description;
 
    @Column(nullable = false, length = 255)
    private String location;
 
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = false)
    private Date startDate;
 
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = false)
    private Date endDate;
 
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = false)
    private Date registrationDeadline;
 
    @Column(nullable = false)
    private int participantsCount = 0;
 
    @Column(nullable = false)
    private int maxParticipants;
 
    @Column(nullable = false)
    private int amount;
 
    // one event --> many registrations
    @OneToMany(mappedBy = "event", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Registration> registrations = new HashSet<>();
 
    @ManyToOne
  	@JoinColumn(name = "created_by", nullable = false)
  	private User createdBy;   // The admin who created this event
 
 
	public Event() {}
 
    // Constructor using java.sql.Date
    public Event(String eventName, String description, String location,
                 Date startDate, Date endDate, Date registrationDeadline,
                 int maxParticipants, int amount) {
        this.eventName = eventName;
        this.description = description;
        this.location = location;
        this.startDate = startDate;
        this.endDate = endDate;
        this.registrationDeadline = registrationDeadline;
        this.maxParticipants = maxParticipants;
        this.participantsCount = 0; // default
        this.amount = amount;
    }
 
    // ✅ Getters & Setters
    public long getEventId() {
        return eventId;
    }
 
    public void setEventId(long eventId) {
        this.eventId = eventId;
    }
 
    public String getEventName() {
        return eventName;
    }
 
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
 
    public String getDescription() {
        return description;
    }
 
    public void setDescription(String description) {
        this.description = description;
    }
 
    public String getLocation() {
        return location;
    }
 
    public void setLocation(String location) {
        this.location = location;
    }
 
    public Date getStartDate() {
        return startDate;
    }
 
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }
 
    public Date getEndDate() {
        return endDate;
    }
 
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
 
    public Date getRegistrationDeadline() {
        return registrationDeadline;
    }
 
    public void setRegistrationDeadline(Date registrationDeadline) {
        this.registrationDeadline = registrationDeadline;
    }
 
    public int getParticipantsCount() {
        return participantsCount;
    }
 
    public void setParticipantsCount(int participantsCount) {
        this.participantsCount = participantsCount;
    }
 
    public int getMaxParticipants() {
        return maxParticipants;
    }
 
    public void setMaxParticipants(int maxParticipants) {
        this.maxParticipants = maxParticipants;
    }
 
    public int getAmount() {
        return amount;
    }
 
    public void setAmount(int amount) {
        this.amount = amount;
    }
 
    public Set<Registration> getRegistrations() {
        return registrations;
    }
 
    public void setRegistrations(Set<Registration> registrations) {
        this.registrations = registrations;
    }
    
    public User getCreatedBy() {
		return createdBy;
	}
 
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
 
    
}