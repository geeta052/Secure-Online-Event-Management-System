package com.soems.security;

import com.soems.dto.UserDTO;
import com.soems.entity.User;
import com.soems.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserService userService;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User entity = userService.findByEmail(email);
        if (entity == null) {
            throw new UsernameNotFoundException("User not found: " + email);
        }
        return  org.springframework.security.core.userdetails.User.withUsername(entity.getEmail())
                .password(entity.getPassword()) // BCrypt hash
                .authorities(new SimpleGrantedAuthority("ROLE_" + entity.getRole()))
                .build();
    }
}