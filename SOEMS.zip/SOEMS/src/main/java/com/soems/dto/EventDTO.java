package com.soems.dto;
 
import java.sql.Date;
 
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.soems.validation.ValidEventDates;
 
@ValidEventDates
public class EventDTO {
    private long eventId;
    @NotBlank(message = "Event title is required")
    @Size(min = 3, max = 100, message = "Event title must be between 3 and 100 characters")
    private String eventName;
 
    @Size(max = 500, message = "Description cannot exceed 500 characters")
    private String description;
 
    @NotBlank(message = "Location is required")
    @Size(max = 255, message = "Location cannot exceed 255 characters")
    private String location;
 
    @NotNull(message = "Start date is required")
    private Date startDate;
 
    @NotNull(message = "End date is required")
    private Date endDate;
 
    @NotNull(message = "Registration deadline is required")
    private Date registrationDeadline;
 
    private int participantsCount;
 
    @Min(value = 1, message = "Max participants must be at least 1")
    private int maxParticipants;
 
    @Min(value = 0, message = "Amount must be zero or positive")
    private int amount;
    
 
    public EventDTO() {
		super();
	}
 
	public EventDTO(long eventId, String eventName, String description, String location,
                    Date startDate, Date endDate, Date registrationDeadline,
                    int participantsCount, int maxParticipants, int amount) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.description = description;
        this.location = location;
        this.startDate = startDate;
        this.endDate = endDate;
        this.registrationDeadline = registrationDeadline;
        this.participantsCount = participantsCount;
        this.maxParticipants = maxParticipants;
        this.amount = amount;
    }
 
	public int getAmount() {
		return amount;
	}
 
	public void setAmount(int amount) {
		this.amount = amount;
	}
 
	public long getEventId() {
		return eventId;
	}
 
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}
 
	public String getEventName() {
		return eventName;
	}
 
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
 
	public String getDescription() {
		return description;
	}
 
	public void setDescription(String description) {
		this.description = description;
	}
 
	public String getLocation() {
		return location;
	}
 
	public void setLocation(String location) {
		this.location = location;
	}
 
	public Date getStartDate() {
		return startDate;
	}
 
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
 
	public Date getEndDate() {
		return endDate;
	}
 
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
 
	public Date getRegistrationDeadline() {
		return registrationDeadline;
	}
 
	public void setRegistrationDeadline(Date registrationDeadline) {
		this.registrationDeadline = registrationDeadline;
	}
 
	public int getParticipantsCount() {
		return participantsCount;
	}
 
	public void setParticipantsCount(int participantsCount) {
		this.participantsCount = participantsCount;
	}
 
	public int getMaxParticipants() {
		return maxParticipants;
	}
 
	public void setMaxParticipants(int maxParticipants) {
		this.maxParticipants = maxParticipants;
	}
 
    
}
 