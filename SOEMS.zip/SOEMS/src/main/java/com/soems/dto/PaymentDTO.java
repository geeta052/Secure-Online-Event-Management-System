package com.soems.dto;
 
import com.soems.entity.Payment.PaymentStatus;
 
public class PaymentDTO {
 
    private long id;
    private long registrationId;
    private long userId;
    private String username;
    private String userEmail;
    private long eventId;
    private double amount;
    private String paymentDate;
    private PaymentStatus paymentStatus;
 
    public PaymentDTO() {
    }
 
    public PaymentDTO(long id, long registrationId, long userId, String username, String userEmail, long eventId, double amount, String paymentDate, PaymentStatus paymentStatus) {
        this.id = id;
        this.registrationId = registrationId;
        this.userId = userId;
        this.username = username;
        this.userEmail = userEmail;
        this.eventId = eventId;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.paymentStatus = paymentStatus;
    }
 
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
 
    public long getRegistrationId() {
        return registrationId;
    }
    public void setRegistrationId(long registrationId) {
        this.registrationId = registrationId;
    }
 
    public long getUserId() {
        return userId;
    }
    public void setUserId(long userId) {
        this.userId = userId;
    }
 
    public long getEventId() {
        return eventId;
    }
    public void setEventId(long eventId) {
        this.eventId = eventId;
    }
 
    public double getAmount() {
        return amount;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }
 
    public String getPaymentDate() {
        return paymentDate;
    }
    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }
 
    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }
    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
 
	public String getUsername() {
		return username;
	}
 
	public void setUsername(String username) {
		this.username = username;
	}
 
	public String getUserEmail() {
		return userEmail;
	}
 
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
    
    
}
 
 