package com.soems.dto;

public class EventStatsDTO {
    private String eventName;
    private int participantsCount;
    private double revenue;

    public EventStatsDTO(String eventName, int participantsCount, double revenue) {
        this.eventName = eventName;
        this.participantsCount = participantsCount;
        this.revenue = revenue;
    }

    public String getEventName() { return eventName; }
    public int getParticipantsCount() { return participantsCount; }
    public double getRevenue() { return revenue; }
}
