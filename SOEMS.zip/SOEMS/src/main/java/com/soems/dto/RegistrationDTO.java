package com.soems.dto;

public class RegistrationDTO {
    private Long id;
    private Long eventId;
    private String registerDate;
    private String eventName;
    private String eventLocation;
    private String username;
    private String userEmail;

    public RegistrationDTO(Long id, Long eventId, String registerDate, String eventName, String eventLocation,
                           String username, String userEmail) {
        this.id = id;
        this.eventId = eventId;
        this.registerDate = registerDate;
        this.eventName = eventName;
        this.eventLocation = eventLocation;
        this.username = username;
        this.userEmail = userEmail;
    }

    public Long getId() {
        return id;
    }

    public Long geteventId() {
        return eventId;
    }

    public String getRegisterDate() {
        return registerDate;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public String getUsername() {
        return username;
    }

    public String getUserEmail() {
        return userEmail;
    }
}
