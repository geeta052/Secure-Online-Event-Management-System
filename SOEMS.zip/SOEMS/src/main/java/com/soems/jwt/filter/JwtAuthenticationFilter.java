package com.soems.jwt.filter;

import com.soems.util.JwtUtil;
import io.jsonwebtoken.Claims;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {

        String path = request.getRequestURI();
        String ctx = request.getContextPath();

        // Public endpoints
        if (path.startsWith("/auth/login") 
                || path.startsWith("/auth/register") 
                || path.startsWith("/auth/logout")
                || path.equals("/") 
                || path.startsWith("/home")
                || path.startsWith("/reset-password")
                || path.startsWith("/login/oauth2/")
                || path.startsWith("/oauth2/authorization")) {
            chain.doFilter(request, response);
            return;
        }

        // For /admin and /dashboard -> take token from cookie
        if (path.contains("/admin") || path.contains("/dashboard") || path.contains("/razorpay")) {
            String token = getJwtFromCookies(request);
            if (token != null) {
                if (authenticateFromToken(token, request, response)) {
                	// Role-based redirect after successful auth
                    String role = (String) request.getAttribute("role");
                    if (path.startsWith(ctx + "/admin") && !"ADMIN".equals(role)) {
                        response.sendRedirect(ctx + "/dashboard");
                        return;
                    }
                    if (path.startsWith(ctx + "/dashboard") && !"USER".equals(role)) {
                        response.sendRedirect(ctx + "/admin");
                        return;
                    }
                    chain.doFilter(request, response);
                    return;
                } else {
                    return; // already wrote 401 response
                }
            } else {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("{\"error\": \"Missing JWT cookie\"}");
                System.out.println("Missing JWT cookie for " + path); 
                response.sendRedirect(request.getContextPath()+  "/auth/login");
                return;
            }
        }

        // For APIs -> take token from Authorization header
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            if (!authenticateFromToken(token, request, response)) {
                return; // invalid token, 401 written
            }
        }
        chain.doFilter(request, response);
    }

    private boolean authenticateFromToken(String token, HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            Claims claims = JwtUtil.validateToken(token);
            String email = claims.getSubject();
            String role = claims.get("role", String.class);
            Long userId = claims.get("userId", Long.class);

            request.setAttribute("role", role);
            request.setAttribute("userId", userId);
            request.setAttribute("username", claims.get("username", String.class));
            request.setAttribute("email", email);

            UsernamePasswordAuthenticationToken auth =
                    new UsernamePasswordAuthenticationToken(
                            email,
                            null,
                            Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
                    );
            SecurityContextHolder.getContext().setAuthentication(auth);
            return true;
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"error\": \"Invalid or expired token\"}");
            System.out.println("Invalid or expired JWT token:  " + e.getMessage()); 
            response.sendRedirect(request.getContextPath() + "/auth/login");
            return false;
        }
    }

    private String getJwtFromCookies(HttpServletRequest req) {
        if (req.getCookies() != null) {
            for (Cookie cookie : req.getCookies()) {
                if ("JWT-TOKEN".equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
