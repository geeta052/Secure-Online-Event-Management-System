package com.soems.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.InMemoryOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;

@Configuration 
public class OAuth2ClientConfig {

    @Bean
    public ClientRegistration googleClientRegistration() {
        return ClientRegistration.withRegistrationId("google") // Unique ID for provider (used in URLs)
                .clientId("134978165963-c375qe8pbin9qhlos62qiplct4im5kcg.apps.googleusercontent.com") // Google client ID
                .clientSecret("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") // Google client secret
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE) // OAuth2 flow: Authorization Code
                .scope("email", "profile") // Permissions requested from Google
                .authorizationUri("https://accounts.google.com/o/oauth2/v2/auth") // Where user is redirected for login
                .tokenUri("https://oauth2.googleapis.com/token") // Exchange code for access token
                .userInfoUri("https://www.googleapis.com/oauth2/v3/userinfo") // Get user profile info
                .userNameAttributeName("sub") // Unique identifier of the user (Google "sub" claim)
                .redirectUri("{baseUrl}/login/oauth2/code/{registrationId}") 
                // Callback URL after login → Spring Security replaces {baseUrl} and {registrationId}
                .clientName("Google") 
                .build();
    }

    
    //Stores client registrations (Google)
     
    @Bean
    public ClientRegistrationRepository clientRegistrationRepository() {
        return new InMemoryClientRegistrationRepository(googleClientRegistration());
    }
    
     // Service that stores authorized client details after user logs in.
     // (e.g., stores access tokens, refresh tokens in memory).
   
    @Bean
    public OAuth2AuthorizedClientService authorizedClientService(
            ClientRegistrationRepository clientRegistrationRepository) {
        return new InMemoryOAuth2AuthorizedClientService(clientRegistrationRepository);
    }
}
