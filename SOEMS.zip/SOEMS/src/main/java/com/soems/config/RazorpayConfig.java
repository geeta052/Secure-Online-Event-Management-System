package com.soems.config;
 
import org.springframework.stereotype.Component;
 
 
@Component
public class RazorpayConfig {
    private final String keyId = "rzp_test_R6i0HnLGF0HaHp";
    private final String keySecret = "IvZn1hQ8SzdaMVgl5mBhVD7I";
 
    public String getKeyId() { return keyId; }
    public String getKeySecret() { return keySecret; }
}
