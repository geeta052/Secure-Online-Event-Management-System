package com.soems.service;

import com.soems.dto.UserDTO;
import com.soems.entity.User;
import java.util.List;

public interface UserService {
    String registerUser(UserDTO userDTO);
    String registerUser(User user);
    User loginUser(String email, String password);
    UserDTO getUserById(Long id);
    List<UserDTO> getAllUsers();
    String updateUser(UserDTO userDTO);
    String deleteUser(Long id);
    User getUserEntityById(Long id);
	User authenticate(String email, String password);
	User findByEmail(String email);
    User findByResetToken(String token);
    void save(User user);
    void updatePassword(User user, String newPassword);
    
    UserDTO findDtoByEmail(String email);
}
