package com.soems.service;
 
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;
 
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.soems.dao.EventDAO;
import com.soems.dao.RegistrationDAO;
import com.soems.dao.UserDAO;
import com.soems.dto.RegistrationDTO;
import com.soems.entity.Event;
import com.soems.entity.Registration;
import com.soems.entity.User;
 
@Service
public class RegistrationServiceImpl implements RegistrationService {
 
    @Autowired
    private RegistrationDAO registrationDAO;
    
    @Autowired
    private EventDAO eventDAO;
    
    @Autowired
    private UserDAO userDAO;
    
    @Autowired
    private EmailService emailService;
 
    @Override
    public String createRegistration(Registration registration) {
    	Event event = eventDAO.findById(registration.getEvent().getEventId());
		if (event == null) {
		    throw new RuntimeException("Event not found");
		}
 
        User user = userDAO.findById(registration.getUser().getId());
		if (user == null) {
		    throw new RuntimeException("User not found");
		}
 
        registration.setEvent(event);
        registration.setUser(user);
        registrationDAO.save(registration);
        return "Registration created successfully!";
    }
 
    @Override
    public RegistrationDTO getRegistrationById(Long id) {
        Registration r = registrationDAO.findById(id);
        return (r != null) ? convertToDTO(r) : null;
    }
 
    @Override
    public List<RegistrationDTO> getAllRegistrations() {
    	return registrationDAO.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
 
 
    @Override
    public String updateRegistration(Registration registration) {
        // Fetch existing registration
        Registration existingReg = registrationDAO.findById(registration.getId());
        if (existingReg == null) {
            throw new RuntimeException("Registration not found");
        }
 
        // Fetch managed Event
        Event event = eventDAO.findById(registration.getEvent().getEventId());
        if (event == null) {
            throw new RuntimeException("Event not found");
        }
 
        // Fetch managed User
        User user = userDAO.findById(registration.getUser().getId());
        if (user == null) {
            throw new RuntimeException("User not found");
        }
 
        // Update fields
        existingReg.setEvent(event);
        existingReg.setUser(user);
        existingReg.setRegisterDate(registration.getRegisterDate());
 
        registrationDAO.update(existingReg);
 
        return "Registration updated successfully!";
    }
 
 
    @Override
    public String deleteRegistration(Long id) {
    	registrationDAO.delete(id);
        return "Registration deleted successfully!";
    }
    
    @Override
    public List<RegistrationDTO> getRegistrationsForEvent(Long eventId) {
    	return registrationDAO.getByEventId(eventId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
 
    @Override
    public List<RegistrationDTO> getRegistrationsForUser(Long userId) {
    	return registrationDAO.getByUserId(userId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional
    public RegistrationDTO registerUserForEvent(Long userId, Long eventId) {
        Event event = eventDAO.findById(eventId);
        if (event == null) {
            throw new RuntimeException("Event not found");
        }
 
        User user = userDAO.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
 
        // Prevent duplicate registration
        List<Registration> existing = registrationDAO.findByUserIdAndEventId(userId, eventId);
        if (!existing.isEmpty()) {
            throw new RuntimeException("User already registered for this event");
        }
 
        // Prevent overbooking
        long currentCount = registrationDAO.countByEventId(eventId);
        if (currentCount >= event.getMaxParticipants()) {
            throw new RuntimeException("Event is fully booked");
        }
        
        // Increment participant count
        event.setParticipantsCount(event.getParticipantsCount() + 1);
        eventDAO.update(event);
 
        // Save new registration
        Registration registration = new Registration();
        registration.setEvent(event);
        registration.setUser(user);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        registration.setRegisterDate(LocalDate.now().format(formatter));
 
        registrationDAO.save(registration);
        
        String userEmail = registration.getUser().getEmail();
        String eventName = registration.getEvent().getEventName();
        Date eventDate = registration.getEvent().getStartDate();
        String location = registration.getEvent().getLocation();
        emailService.sendRegistrationEmail(userEmail, eventName, eventDate, location);
 
        return convertToDTO(registration);
    }
    
    @Override
    @Transactional
    public boolean cancelRegistration(Long userId, Long eventId) {
        boolean deleted = registrationDAO.deleteByUserIdAndEventId(userId, eventId);
        if (deleted) {
            Event event = eventDAO.findById(eventId);
            if (event != null && event.getParticipantsCount() > 0) {
                event.setParticipantsCount(event.getParticipantsCount() - 1);
                eventDAO.update(event);
            }
        }
        return deleted;
    }
    
    private RegistrationDTO convertToDTO(Registration r) {
        return new RegistrationDTO(
            r.getId(),
            r.getEvent().getEventId(),
            r.getRegisterDate().toString(),
            r.getEvent().getEventName(),
            r.getEvent().getLocation(),
            r.getUser().getUsername(),
            r.getUser().getEmail()
        );
    }
 
}
 
 