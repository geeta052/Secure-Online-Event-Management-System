package com.soems.service;

import java.util.List;

import com.soems.dto.EventStatsDTO;

public interface ReportService {
	List<EventStatsDTO> getEventStats(Long adminId);
}
