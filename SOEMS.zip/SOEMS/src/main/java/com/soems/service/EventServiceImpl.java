package com.soems.service;
 
import java.util.List;
import java.util.stream.Collectors;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.soems.dao.EventDAO;
import com.soems.dao.EventHistoryDAO;
import com.soems.dto.EventDTO;
import com.soems.entity.Event;
import com.soems.entity.EventHistory;
import com.soems.entity.User;

 
@Service
public class EventServiceImpl implements EventService {
 
	@Autowired
	private EventDAO eventDAO;
	
	@Autowired
	private EventHistoryDAO eventHistoryDAO;
 
	// create new event
	@Override
	public String createEvent(EventDTO eventDTO, User createdBy) {
		Event event = convertToEntity(eventDTO, createdBy); // Map DTO to Entity
		eventDAO.save(event);
		System.out.println("Event created");
		return "Event created successfully!";
	}
	
	// get event by id
	@Override
	public EventDTO getEventById(Long id) {
		Event event = eventDAO.findById(id);
		return event != null ? convertToDTO(event) : null;
	}
 
	// get all events
	@Override
	public List<EventDTO> getAllEvents() {
		return eventDAO.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
	}
 
	// update event
	@Override
	public String updateEvent(EventDTO eventDTO, User updatedBy) {
		Event existingEvent = eventDAO.findById(eventDTO.getEventId());
	    if (existingEvent == null) {
	        return "Event not found!";
	    }
	    
	    // Map DTO to the existing entity to update its fields
	    existingEvent.setEventName(eventDTO.getEventName());
	    existingEvent.setDescription(eventDTO.getDescription());
	    existingEvent.setLocation(eventDTO.getLocation());
	    existingEvent.setStartDate(eventDTO.getStartDate());
	    existingEvent.setEndDate(eventDTO.getEndDate());
	    existingEvent.setRegistrationDeadline(eventDTO.getRegistrationDeadline());
	    existingEvent.setMaxParticipants(eventDTO.getMaxParticipants());
	    existingEvent.setAmount(eventDTO.getAmount());
	    existingEvent.setCreatedBy(updatedBy); // Set the updating admin
	    
	    eventDAO.update(existingEvent);
		return "Event updated successfully!";
	}
 
	// delete event
	@Override
	public String deleteEvent(Long id, Long adminId) {
		Event event = eventDAO.findById(id);
		if (event != null) {
	        EventHistory history = new EventHistory(event, adminId);
	        eventHistoryDAO.save(history);
	        eventDAO.delete(id);
	        return "Event deleted and history saved!";
	    }
	    return "Event not found!";
	}
 
	// get available seats in an event
	@Override
	public int getAvailableSeats(Long eventId) {
		Event event = eventDAO.findById(eventId);
		if (event == null) {
			throw new RuntimeException("Event not found with ID: " + eventId);
		}
		return event.getMaxParticipants() - event.getParticipantsCount();
	}
 
	// get all upcoming events
	@Override
	public List<EventDTO> getUpcomingEvents() {
		return eventDAO.getUpcomingEvents().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
	}
	
	// search event by filters
	public List<EventDTO> searchEvents(String location, Double maxAmount, String startDate, String eventName) {
		return eventDAO.findEventsByFilter(location, maxAmount, startDate, eventName).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
	}
 
	// get all events created by admin
	public List<EventDTO> getEventsByAdmin(Long adminId) {
		return eventDAO.findEventsByAdmin(adminId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
	}
	
	@Override
    public List<Event> getAllEventsEntity() {
        return eventDAO.findAll();
    }
	
	@Override
	public List<EventHistory> getAllDeletedEvents() {
	    return eventHistoryDAO.findAll();
	}
	
	@Override
	public List<EventHistory> getAllDeletedEventsByAdmin(Long adminId) {
	    return eventHistoryDAO.findByDeletedBy(adminId);
	}
	
	private Event convertToEntity(EventDTO dto, User createdBy) {
	    Event event = new Event();
	    event.setEventId(dto.getEventId());
	    event.setEventName(dto.getEventName());
	    event.setDescription(dto.getDescription());
	    event.setLocation(dto.getLocation());
	    event.setStartDate(dto.getStartDate());
	    event.setEndDate(dto.getEndDate());
	    event.setRegistrationDeadline(dto.getRegistrationDeadline());
	    event.setParticipantsCount(dto.getParticipantsCount());
	    event.setMaxParticipants(dto.getMaxParticipants());
	    event.setAmount(dto.getAmount());
	    event.setCreatedBy(createdBy);
	    return event;
	}
	
	private EventDTO convertToDTO(Event event) {
        return new EventDTO(
            event.getEventId(),
            event.getEventName(),
            event.getDescription(),
            event.getLocation(),
            event.getStartDate(),
            event.getEndDate(),
            event.getRegistrationDeadline(),
            event.getParticipantsCount(),
            event.getMaxParticipants(),
            event.getAmount()
        );
    }
}
 