package com.soems.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.soems.dao.EventDAO;
import com.soems.dao.PaymentDAO;
import com.soems.dto.EventStatsDTO;
import com.soems.entity.Event;

@Service
public class ReportServiceImpl implements ReportService {

	@Autowired
    private EventDAO eventDAO;

    @Autowired
    private PaymentDAO paymentDAO;

    @Transactional(readOnly = true)
    public List<EventStatsDTO> getEventStats(Long adminId) {
    	List<Event> events = eventDAO.findEventsByAdmin(adminId);
        List<EventStatsDTO> stats = new ArrayList<>();

        for (Event event : events) {
        	double revenue = paymentDAO.getEventRevenue(event.getEventId());

            stats.add(new EventStatsDTO(
                event.getEventName(),
                event.getParticipantsCount(),
                revenue
            ));
        }
        return stats;
    }
}
