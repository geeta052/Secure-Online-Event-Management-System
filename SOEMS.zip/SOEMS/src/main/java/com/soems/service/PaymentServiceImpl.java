package com.soems.service;
 
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.Utils;
import com.soems.config.RazorpayConfig;
import com.soems.dao.EventDAO;
import com.soems.dao.PaymentDAO;
import com.soems.dao.RegistrationDAO;
import com.soems.dao.UserDAO;
import com.soems.dto.PaymentDTO;
import com.soems.dto.RegistrationDTO;
import com.soems.entity.Event;
import com.soems.entity.Payment;
import com.soems.entity.Payment.PaymentStatus;
import com.soems.entity.Registration;
import com.soems.entity.User;
 
@Service
public class PaymentServiceImpl implements PaymentService {
 
    @Autowired
    private PaymentDAO paymentDAO;
    
    @Autowired
    private EventDAO eventDAO;
 
    @Autowired
    private UserDAO userDAO;
    
    @Autowired
    private RegistrationDAO registrationDAO;
    
    @Autowired
    private RegistrationService registrationService;
    
    @Autowired
    private RazorpayConfig razorpayConfig;
    
    // make payment after registration
    @Override
    public PaymentDTO makePayment(PaymentDTO paymentDTO) {
        Registration registration = registrationDAO.findById(paymentDTO.getRegistrationId());
        if (registration == null) {
            throw new RuntimeException("Registration not found");
        }
        
        User user = userDAO.findById(paymentDTO.getUserId());
        if (user == null) {
		    throw new RuntimeException("User not found");
		}
        
        Event event = eventDAO.findById(paymentDTO.getEventId());
        if (event == null) {
		    throw new RuntimeException("Event not found");
		}
 
        Payment payment = new Payment();
        payment.setRegistration(registration);
        payment.setAmount(paymentDTO.getAmount());
        payment.setPaymentStatus(paymentDTO.getPaymentStatus());
        payment.setPaymentDate(paymentDTO.getPaymentDate());
 
        paymentDAO.save(payment);
 
        return convertToDTO(payment);
    }
 
 
    // get payment by id
    @Override
    public PaymentDTO getPaymentById(long id) {
        Payment payment = paymentDAO.getById(id);
        if (payment == null) {
            throw new RuntimeException("Payment not found");
        }
 
        return convertToDTO(payment);
    }
 
    // get all payments by registration id
    @Override
    public List<PaymentDTO> getPaymentsByRegistrationId(long registrationId) {
        List<Payment> payments = paymentDAO.getByRegistrationId(registrationId);
 
        return payments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    // get revenue of an event
    @Override
    public double getEventRevenueReport(Long eventId) {
        return paymentDAO.getEventRevenue(eventId);
    }
    
    @Override
    public List<PaymentDTO> getPaymentsForUser(Long userId) {
        return paymentDAO.getPaymentsForUser(userId);
    }
 
    @Override
    public List<PaymentDTO> getPaymentsForEvent(Long eventId) {
        return paymentDAO.getPaymentsForEvent(eventId);
    }
    
    private PaymentDTO convertToDTO(Payment payment) {
        if (payment == null) return null;
 
        return new PaymentDTO(
                payment.getId(),
                payment.getRegistration().getId(),
                payment.getRegistration().getUser().getId(),
                payment.getRegistration().getUser().getUsername(),
                payment.getRegistration().getUser().getEmail(),
                payment.getRegistration().getEvent().getEventId(),
                payment.getAmount(),
                payment.getPaymentDate(),
                payment.getPaymentStatus()
        );
    }
    
    public String createRazorpayOrder(int amount) throws Exception {
        RazorpayClient client = new RazorpayClient(
                razorpayConfig.getKeyId(),
                razorpayConfig.getKeySecret()
        );
 
        JSONObject options = new JSONObject();
        options.put("amount", amount * 100); 
        options.put("currency", "INR");
        options.put("receipt", "txn_" + System.currentTimeMillis());
 
        Order order = client.orders.create(options);
        return order.toString();
    }
 
 
    @Override
    public boolean verifySignature(Map<String, String> data) {
        try {
            String orderId = data.get("razorpay_order_id");
            String paymentId = data.get("razorpay_payment_id");
            String signature = data.get("razorpay_signature");
 
            String payload = orderId + "|" + paymentId;
 
            return Utils.verifySignature(payload, signature, razorpayConfig.getKeySecret());
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public String verifyAndRegisterPayment(Map<String, String> data) {
        boolean valid = verifySignature(data);
        if (!valid) {
            throw new RuntimeException("Invalid Razorpay signature!");
        }

        Long userId = Long.parseLong(data.get("userId"));
        Long eventId = Long.parseLong(data.get("eventId"));
        double amount = Double.parseDouble(data.get("amount"));

        // Register user for event
        RegistrationDTO regDto = registrationService.registerUserForEvent(userId, eventId);

        // Save payment in DB
        Payment payment = new Payment();
        payment.setRegistration(registrationDAO.findById(regDto.getId()));
        payment.setAmount(amount);
        payment.setPaymentStatus(PaymentStatus.PAID);
        payment.setPaymentDate(LocalDate.now().toString());

        paymentDAO.save(payment);

        return "Payment successful and registration completed!";
    }

    
}
 