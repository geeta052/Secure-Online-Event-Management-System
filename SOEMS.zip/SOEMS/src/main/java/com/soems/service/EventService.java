package com.soems.service;

import java.util.List;

import com.soems.dto.EventDTO;
import com.soems.dto.UserDTO;
import com.soems.entity.Event;
import com.soems.entity.EventHistory;
import com.soems.entity.User;

public interface EventService {
    String createEvent(EventDTO eventDTO, User createdBy);
    EventDTO getEventById(Long id);
    List<EventDTO> getAllEvents();
    String updateEvent(EventDTO eventDTO, User createdBy);
    String deleteEvent(Long id, Long adminId);    
    int getAvailableSeats(Long eventId);
    List<EventDTO> getUpcomingEvents();
    List<EventDTO> searchEvents(String location, Double maxAmount, String startDate, String eventName);
    List<EventDTO> getEventsByAdmin(Long adminId);
	List<Event> getAllEventsEntity();
	List<EventHistory> getAllDeletedEvents();
	List<EventHistory> getAllDeletedEventsByAdmin(Long adminId);
}
