package com.soems.service;
 
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
 
import com.soems.dao.UserDAO;
import com.soems.dto.UserDTO;
import com.soems.entity.User;
 
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDAO userDao;
	
	private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
 
	@Override
	public String registerUser(UserDTO userDTO) {
		User user = new User();
	    user.setUsername(userDTO.getUsername());
	    user.setEmail(userDTO.getEmail());
	    user.setPassword(userDTO.getPassword());
	    user.setConfirmPassword(userDTO.getConfirmPassword()); // Set confirmPassword
	    user.setRole(userDTO.getRole()); // Set a default role for new users
 
	    
		if(userDao.findByEmail(user.getEmail()) != null) {
			return "Email already exists!";
		}
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		userDao.save(user);
		return "User registered successfully!";
	}
	
	@Override
	public String registerUser(User user) {
	    if (userDao.findByEmail(user.getEmail()) != null) {
	        return "Email already exists!";
	    }
	    // No password encoding needed for OAuth2 dummy
	    userDao.save(user);
	    return "User registered successfully!";
	}
	
	@Override
	public User loginUser(String email, String password) {
		User exist = userDao.findByEmail(email);
		if(exist != null && passwordEncoder.matches(password, exist.getPassword())) {
			return exist;
		}
		return null;
	}
 
	@Override
	public UserDTO getUserById(Long id) {
	    User user = userDao.findById(id);
	    return convertToDTO(user);
	}
 
	@Override
	public List<UserDTO> getAllUsers() {
		return userDao.findAll().stream()
		        .map(this::convertToDTO)
		        .collect(Collectors.toList());
	}
 
 
	@Override
	public String updateUser(UserDTO userDTO) {
	    // Fetch existing user from DB
	    User existingUser = userDao.findById(userDTO.getId());
	    if (existingUser == null) {
	        return "User not found!";
	    }
	
	    existingUser.setUsername(userDTO.getUsername());
	    existingUser.setEmail(userDTO.getEmail());
	   
 
	    if (userDTO.getPassword() != null && !userDTO.getPassword().isEmpty()) {
	        existingUser.setPassword(passwordEncoder.encode(userDTO.getPassword()));
	    }
 
	    userDao.update(existingUser);
	    return "User updated successfully!";
	}
 
	@Override
	public String deleteUser(Long id) {
		userDao.delete(id);
		return "User deleted successfully!";
	}
	
	@Override
	public User getUserEntityById(Long id) {
	    return userDao.findById(id); 
	}
	
	@Override
	public User authenticate(String email, String password) {
	    User exist = userDao.findByEmail(email);
	    if (exist != null && passwordEncoder.matches(password, exist.getPassword())) {
	        return exist; 
	    }
	    return null;
	}
	
	@Override
    public User findByEmail(String email) {
        return userDao.findByEmail(email);
    }
	
	@Override
    public UserDTO findDtoByEmail(String email) {
        User user = userDao.findByEmail(email);
        return convertToDTO(user);
    }

    @Override
    public User findByResetToken(String token) {
        return userDao.findByResetToken(token);
    }

    @Override
    public void save(User user) {
        userDao.saveOrUpdate(user);
    }

    @Override
    public void updatePassword(User user, String newPassword) {
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setResetToken(null); // clear token after reset
        userDao.update(user);
    }
 
 
	private UserDTO convertToDTO(User user) {
	    if (user == null) return null;
	    return new UserDTO(
	        user.getId(),
	        user.getUsername(),
	        user.getEmail(),
	        user.getRole()
	    );
	}
}
 
 