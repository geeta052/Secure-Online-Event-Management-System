package com.soems.service;
 
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Date;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
 
@Service
public class EmailService {
 
    @Autowired
    private JavaMailSender mailSender;
    
    public void sendRegistrationEmail(String to, String eventName, Date eventDate, String location) {
        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");

            helper.setTo(to);
            helper.setSubject("🎉 Registration Confirmed: " + eventName);

            String htmlContent = "<div style='font-family: Arial, sans-serif; padding: 20px; color: #333;'>"
                    + "<h2 style='color: #4CAF50;'>Registration Successful 🎊</h2>"
                    + "<p>Hi there,</p>"
                    + "<p>You have successfully registered for the event:</p>"
                    + "<table style='border-collapse: collapse; margin-top: 10px;'>"
                    + "  <tr><td style='padding: 6px;'><b>📌 Event:</b></td><td>" + eventName + "</td></tr>"
                    + "  <tr><td style='padding: 6px;'><b>📅 Date:</b></td><td>" + eventDate + "</td></tr>"
                    + "  <tr><td style='padding: 6px;'><b>📍 Location:</b></td><td>" + location + "</td></tr>"
                    + "</table>"
                    + "<br><p>✅ Please arrive at least <b>15 minutes early</b>.</p>"
                    + "<p>💡 Keep this email as your entry confirmation.</p>"
                    + "<br><p style='color:#888;'>Best Regards,<br>SOEMS Team</p>"
                    + "</div>";

            helper.setText(htmlContent, true);

            mailSender.send(mimeMessage);

        } catch (Exception e) {
            throw new RuntimeException("Failed to send registration email", e);
        }
    }
    
    public void sendPasswordResetEmail(String to, String token, String appUrl) {
    	String encodedToken = URLEncoder.encode(token, StandardCharsets.UTF_8);
        String resetLink = appUrl + "/reset-password?token=" + encodedToken;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Password Reset Request");
        message.setText("Click the link below to reset your password:\n" + resetLink);

        mailSender.send(message);
    }
}
 