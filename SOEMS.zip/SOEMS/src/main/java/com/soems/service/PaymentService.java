package com.soems.service;
 
import java.util.List;
import java.util.Map;

import com.soems.dto.PaymentDTO;
 
public interface PaymentService {
//    void savePayment(Payment payment);
	PaymentDTO makePayment(PaymentDTO paymentDTO);
	PaymentDTO getPaymentById(long id);
    List<PaymentDTO> getPaymentsByRegistrationId(long registrationId);
    double getEventRevenueReport(Long eventId); 
    List<PaymentDTO> getPaymentsForUser(Long userId);
    List<PaymentDTO> getPaymentsForEvent(Long eventId);
    String createRazorpayOrder(int amount) throws Exception;
    boolean verifySignature(Map<String, String> data);
	String verifyAndRegisterPayment(Map<String, String> data);
}