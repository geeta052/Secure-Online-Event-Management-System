package com.soems.validation;

import com.soems.dto.EventDTO;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.sql.Date;

public class EventDateValidator implements ConstraintValidator<ValidEventDates, EventDTO> {

    @Override
    public boolean isValid(EventDTO event, ConstraintValidatorContext context) {
        // If no event object is provided, don't fail validation here.
        // (@NotNull on DTO itself can handle null cases)
        if (event == null) return true;

        // Extract event dates
        Date startDate = event.getStartDate();
        Date endDate = event.getEndDate();
        Date registrationDeadline = event.getRegistrationDeadline();

        // If any date is missing, skip checks here.
        // Separate @NotNull annotations will handle required fields.
        if (startDate == null || endDate == null || registrationDeadline == null) {
            return true;
        }

        // Get today's date (no time, just the current day)
        Date today = new Date(System.currentTimeMillis());
        boolean valid = true;

        // Rule 1: startDate must be today or in the future
        if (startDate.before(today)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Start date cannot be in the past")
                   .addPropertyNode("startDate") // points error at "startDate" field
                   .addConstraintViolation();
            valid = false;
        }

        // Rule 2: endDate must be after or same as startDate
        if (endDate.before(startDate)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("End date cannot be before start date")
                   .addPropertyNode("endDate")
                   .addConstraintViolation();
            valid = false;
        }

        // Rule 3: registrationDeadline must be today or in the future
        if (registrationDeadline.before(today)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Registration deadline cannot be in the past")
                   .addPropertyNode("registrationDeadline")
                   .addConstraintViolation();
            valid = false;
        }

        // Rule 4: registrationDeadline must be on/before the startDate
        if (registrationDeadline.after(startDate)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Registration deadline must be on or before the start date")
                   .addPropertyNode("registrationDeadline")
                   .addConstraintViolation();
            valid = false;
        }

        return valid;
    }
}
