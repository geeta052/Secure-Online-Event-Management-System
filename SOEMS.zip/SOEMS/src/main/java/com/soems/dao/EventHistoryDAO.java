package com.soems.dao;

import java.util.List;

import com.soems.entity.EventHistory;

public interface EventHistoryDAO {
	 void save(EventHistory history);
	 List<EventHistory> findAll();
	 List<EventHistory> findByDeletedBy(Long adminId);
}
