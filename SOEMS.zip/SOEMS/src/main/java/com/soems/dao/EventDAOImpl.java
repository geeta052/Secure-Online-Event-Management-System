package com.soems.dao;
 
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
 
import com.soems.entity.Event;
 
@Repository
public class EventDAOImpl implements EventDAO {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    // save event
    @Override
    public void save(Event event) {
        // sessionFactory.getCurrentSession().save(event);
        Session session = sessionFactory.openSession();   
        Transaction tx = session.beginTransaction();      
        session.save(event);
        tx.commit();                                      
        session.close();                                  
    }
 
    // get event by id
    @Override
    public Event findById(Long id) {
        // return sessionFactory.getCurrentSession().get(Event.class, id);
        Session session = sessionFactory.openSession();   
        Event event = session.get(Event.class, id);       
        session.close();                                  
        return event;
    }
 
    // get all events
    @Override
    public List<Event> findAll() {
        // return sessionFactory.getCurrentSession().createQuery("FROM Event", Event.class).getResultList();
        Session session = sessionFactory.openSession();   
        List<Event> events = session.createQuery("FROM Event", Event.class).getResultList();
        session.close();                                  
        return events;
    }
 
    // update event
    @Override
    public void update(Event event) {
        // sessionFactory.getCurrentSession().update(event);
        Session session = sessionFactory.openSession();   
        Transaction tx = session.beginTransaction();      
        session.update(event);
        tx.commit();                                      
        session.close();                                 
    }
 
    // delete event
    @Override
    public void delete(Long id) {
        // Event ev = findById(id);
        // if (ev != null) {
        //     sessionFactory.getCurrentSession().delete(ev);
        // }
        Session session = sessionFactory.openSession();   
        Transaction tx = session.beginTransaction();      
        Event ev = session.get(Event.class, id);
        if (ev != null) {
            session.delete(ev);
        }
        tx.commit();                                      
        session.close();                                  
    }
 
    // get all upcoming events
    @Override
    public List<Event> getUpcomingEvents() {
        // Session session = sessionFactory.getCurrentSession();
        Session session = sessionFactory.openSession();   
        Date today = new Date(System.currentTimeMillis());
 
        List<Event> events = session.createQuery(
                "FROM Event e WHERE e.startDate >= :today ORDER BY e.startDate ASC",
                Event.class
        ).setParameter("today", today)
         .getResultList();
 
        session.close();                                  
        return events;
    }
 
    // get events by filters
    @Override
    public List<Event> findEventsByFilter(String location, Double maxAmount, String startDate, String eventName) {
        // Session session = sessionFactory.getCurrentSession();
        Session session = sessionFactory.openSession();  
        var cb = session.getCriteriaBuilder();
        var cq = cb.createQuery(Event.class);
        var root = cq.from(Event.class);
 
        List<javax.persistence.criteria.Predicate> predicates = new java.util.ArrayList<>();
 
        if (location != null && !location.isEmpty()) {
            predicates.add(cb.like(cb.lower(root.get("location")), "%" + location.toLowerCase() + "%"));
        }
 
        if (maxAmount != null) {
            predicates.add(cb.le(root.get("amount"), maxAmount));
        }
 
        if (startDate != null) {
            LocalDate parsedDate = LocalDate.parse(startDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            java.sql.Date sqlDate = java.sql.Date.valueOf(parsedDate);
            predicates.add(cb.greaterThanOrEqualTo(root.get("startDate"), sqlDate));
        }
 
        if (eventName != null && !eventName.isEmpty()) {
            predicates.add(cb.like(cb.lower(root.get("eventName")), "%" + eventName.toLowerCase() + "%"));
        }
 
        cq.select(root).where(predicates.toArray(new javax.persistence.criteria.Predicate[0]));
 
        List<Event> events = session.createQuery(cq).getResultList();
        session.close();                                  
        return events;
    }
 
    // get all events created by that admin
    @Override
    public List<Event> findEventsByAdmin(Long adminId) {
        // return sessionFactory.getCurrentSession().createQuery(...).setParameter(...).getResultList();
        Session session = sessionFactory.openSession();   
        List<Event> events = session.createQuery(
                "FROM Event e WHERE e.createdBy.id = :adminId", Event.class
        ).setParameter("adminId", adminId)
         .getResultList();
        session.close();                                  
        return events;
    }
}