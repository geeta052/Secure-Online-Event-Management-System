package com.soems.dao;
 
import java.util.List;

import com.soems.dto.PaymentDTO;
import com.soems.entity.Payment;
 
public interface PaymentDAO {
    void save(Payment payment);
    Payment getById(long id);
    List<Payment> getByRegistrationId(long registrationId);
    double getEventRevenue(Long eventId);
    List<PaymentDTO> getPaymentsForUser(Long userId);
    List<PaymentDTO> getPaymentsForEvent(Long eventId);
}
 