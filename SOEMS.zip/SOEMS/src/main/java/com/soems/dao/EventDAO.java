package com.soems.dao;

import java.util.List;
import com.soems.entity.Event;

public interface EventDAO {
    void save(Event event);
    Event findById(Long id);
    List<Event> findAll();
    void update(Event event);
    void delete(Long id);   
    List<Event> getUpcomingEvents();
    List<Event> findEventsByFilter(String location, Double maxAmount, String startDate, String eventName);
	List<Event> findEventsByAdmin(Long adminId);
}
