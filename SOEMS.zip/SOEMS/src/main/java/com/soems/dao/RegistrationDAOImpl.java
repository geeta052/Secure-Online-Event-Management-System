package com.soems.dao;
 
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.soems.entity.Registration;
 
@Repository
public class RegistrationDAOImpl implements RegistrationDAO {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    // save registration
    @Override
    public void save(Registration registration) {
        // sessionFactory.getCurrentSession().save(registration);
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(registration);
        tx.commit();
        session.close();
    }
 
    // get registration by id
    @Override
    public Registration findById(Long id) {
        Session session = sessionFactory.openSession();   
        Registration reg = session.get(Registration.class, id);
        session.close();
        return reg;
    }
 
    // get all registrations
    @Override
    public List<Registration> findAll() {
        Session session = sessionFactory.openSession();  
        List<Registration> regs = session
                .createQuery("from Registration", Registration.class)
                .getResultList();
        session.close();
        return regs;
    }
 
    // update registration
    @Override
    public void update(Registration registration) {
        Session session = sessionFactory.openSession();   
        Transaction tx = session.beginTransaction();
        session.update(registration);
        tx.commit();
        session.close();
    }
 
    // delete registration
    @Override
    public void delete(Long id) {
        Session session = sessionFactory.openSession();   
        Transaction tx = session.beginTransaction();
        Registration reg = session.get(Registration.class, id);
        if (reg != null) {
            session.delete(reg);
        }
        tx.commit();
        session.close();
    }
 
    // get all registrations for an event
    @Override
    public List<Registration> getByEventId(Long eventId) {
        Session session = sessionFactory.openSession();   
        List<Registration> regs = session.createQuery(
                    "SELECT r FROM Registration r " +
                    "JOIN FETCH r.user u " +
                    "JOIN FETCH r.event e " +
                    "WHERE e.eventId = :eventId",
                    Registration.class
                )
                .setParameter("eventId", eventId)
                .getResultList();
        session.close();
        return regs;
    }
 
    // get all registrations for a user
    @Override
    public List<Registration> getByUserId(Long userId) {
        Session session = sessionFactory.openSession();   
        List<Registration> regs = session.createQuery(
                    "SELECT r FROM Registration r " +
                    "JOIN FETCH r.event e " +
                    "JOIN FETCH r.user u " +
                    "WHERE u.id = :userId",
                    Registration.class
                )
                .setParameter("userId", userId)
                .getResultList();
        session.close();
        return regs;
    }
 
    // get registration by userId and eventId
    @Override
    public List<Registration> findByUserIdAndEventId(Long userId, Long eventId) {
        Session session = sessionFactory.openSession();   
        List<Registration> regs = session.createQuery(
                    "FROM Registration r WHERE r.user.id = :userId AND r.event.eventId = :eventId",
                    Registration.class
                )
                .setParameter("userId", userId)
                .setParameter("eventId", eventId)
                .getResultList();
        session.close();
        return regs;
    }
 
    // count registrations for an event
    @Override
    public long countByEventId(Long eventId) {
        Session session = sessionFactory.openSession();   
        Long count = session.createQuery(
                    "SELECT COUNT(r) FROM Registration r WHERE r.event.eventId = :eventId",
                    Long.class
                )
                .setParameter("eventId", eventId)
                .uniqueResult();
        session.close();
        return count != null ? count : 0;
    }
 
    // delete registrations by userid and eventid
    @Override
    public boolean deleteByUserIdAndEventId(Long userId, Long eventId) {
        Session session = sessionFactory.openSession();  
        Transaction tx = session.beginTransaction();
        
        List<Registration> registrations = findByUserIdAndEventId(userId, eventId);
        if (!registrations.isEmpty()) {
            for (Registration reg : registrations) {
                // delete payments first
                session.createQuery("DELETE FROM Payment p WHERE p.registration.id = :regId")
                       .setParameter("regId", reg.getId())
                       .executeUpdate();
                // delete registration
                session.delete(reg);
            }
            tx.commit();
            session.close();
            return true;
        }
        tx.commit();
        session.close();
        return false;
    }
}