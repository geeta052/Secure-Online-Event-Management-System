package com.soems.dao;
 
import java.util.List;
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
 
import com.soems.entity.EventHistory;
 
@Repository
public class EventHistoryDAOImpl implements EventHistoryDAO {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    @Override
    public void save(EventHistory history) {
        // sessionFactory.getCurrentSession().save(history);
        Session session = sessionFactory.openSession();    
        Transaction tx = session.beginTransaction();      
        session.save(history);
        tx.commit();                                      
        session.close();                                  
    }
 
    @Override
    public List<EventHistory> findAll() {
        // return sessionFactory.getCurrentSession()
        //         .createQuery("FROM EventHistory", EventHistory.class)
        //         .getResultList();
        Session session = sessionFactory.openSession();    
        List<EventHistory> histories = session
                .createQuery("FROM EventHistory", EventHistory.class)
                .getResultList();
        session.close();                                  
        return histories;
    }
 
    @Override
    public List<EventHistory> findByDeletedBy(Long adminId) {
        // return sessionFactory.getCurrentSession()
        //         .createQuery("FROM EventHistory e WHERE e.deletedBy = :adminId", EventHistory.class)
        //         .setParameter("adminId", adminId)
        //         .getResultList();
        Session session = sessionFactory.openSession();    
        List<EventHistory> histories = session
                .createQuery("FROM EventHistory e WHERE e.deletedBy = :adminId", EventHistory.class)
                .setParameter("adminId", adminId)
                .getResultList();
        session.close();                                   
        return histories;
    }
}