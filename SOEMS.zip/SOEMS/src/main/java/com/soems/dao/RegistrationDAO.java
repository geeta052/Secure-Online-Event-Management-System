package com.soems.dao;

import java.util.List;
import com.soems.entity.Registration;

public interface RegistrationDAO {
    void save(Registration registration);
    Registration findById(Long id);
    List<Registration> findAll();
    void update(Registration registration);
    void delete(Long id);  
    List<Registration> getByEventId(Long eventId);
    List<Registration> getByUserId(Long userId);
    List<Registration> findByUserIdAndEventId(Long userId, Long eventId);
    long countByEventId(Long eventId);
    boolean deleteByUserIdAndEventId(Long userId, Long eventId);
}
