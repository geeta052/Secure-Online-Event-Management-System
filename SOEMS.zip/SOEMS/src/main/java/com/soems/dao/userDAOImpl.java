package com.soems.dao;
 
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
 
import com.soems.entity.User;
 
@Repository
public class userDAOImpl implements UserDAO {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    @Override
    public void save(User user) {
        // sessionFactory.getCurrentSession().save(user);
        Session session = sessionFactory.openSession();  
        Transaction tx = session.beginTransaction();     
        session.save(user);
        tx.commit();                                    
        session.close(); // close session
    }
 
    @Override
    public User findByEmail(String email) {
        // sessionFactory.getCurrentSession().createQuery(...).uniqueResult();
        Session session = sessionFactory.openSession();
        User user = session.createQuery("from User where email=:email", User.class)
                           .setParameter("email", email)
                           .uniqueResult();
        session.close();  
        return user;
    }
 
    @Override
    public User findById(Long id) {
        // sessionFactory.getCurrentSession().get(User.class, id);
        Session session = sessionFactory.openSession();
        User user = session.get(User.class, id);
        session.close();
        return user;
    }
 
    @Override
    public List<User> findAll() {
        // sessionFactory.getCurrentSession().createQuery("from User", User.class).getResultList();
        Session session = sessionFactory.openSession();
        List<User> users = session.createQuery("from User", User.class).getResultList();
        session.close();
        return users;
    }
 
    @Override
    public void update(User user) {
        //sessionFactory.getCurrentSession().update(user);
        Session session = sessionFactory.openSession();    
        Transaction tx = session.beginTransaction();
        session.update(user);
        tx.commit();
        session.close();
    }
 
    @Override
    public void delete(Long id) {
        // sessionFactory.getCurrentSession().delete(u);
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        User u = session.get(User.class, id);
        if (u != null) {
            session.delete(u);
        }
        tx.commit();
        session.close();
    }
 
    @Override
    public User findByResetToken(String token) {
        // sessionFactory.getCurrentSession().createQuery(...).uniqueResult();
        Session session = sessionFactory.openSession();
        User user = session.createQuery("from User where resetToken=:token", User.class)
                           .setParameter("token", token)
                           .uniqueResult();
        session.close();
        return user;
    }
 
    @Override
    public void saveOrUpdate(User user) {
        // sessionFactory.getCurrentSession().saveOrUpdate(user);
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.saveOrUpdate(user);
        tx.commit();
        session.close();
    }
}
 
 