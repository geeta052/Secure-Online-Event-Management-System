package com.soems.dao;
 
import java.util.List;
import java.util.stream.Collectors;
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
 
import com.soems.dto.PaymentDTO;
import com.soems.entity.Payment;
 
@Repository
public class PaymentDAOImpl implements PaymentDAO {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    // save payment
    @Override
    public void save(Payment payment) {
        // sessionFactory.getCurrentSession().save(payment);
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(payment);
        tx.commit();
        session.close();
    }
 
    // get payment by id
    @Override
    public Payment getById(long id) {
        Session session = sessionFactory.openSession();   
        Payment payment = session.get(Payment.class, id);
        session.close();
        return payment;
    }
 
    // get payment by registration id
    @Override
    public List<Payment> getByRegistrationId(long registrationId) {
        Session session = sessionFactory.openSession();   
        List<Payment> payments = session.createQuery(
                    "FROM Payment p WHERE p.registration.id = :registrationId",
                    Payment.class
                )
                .setParameter("registrationId", registrationId)
                .getResultList();
        session.close();
        return payments;
    }
 
    // get revenue of an event
    @Override
    public double getEventRevenue(Long eventId) {
        Session session = sessionFactory.openSession();   
        Double totalRevenue = session.createQuery(
        		"SELECT SUM(p.amount) FROM Payment p " +
                        "JOIN p.registration r " +
                        "JOIN r.event e " +
                        "WHERE e.eventId = :eventId AND p.paymentStatus = 'PAID'",
                    Double.class
                )
                .setParameter("eventId", eventId)
                .uniqueResult();
        session.close();
        return totalRevenue != null ? totalRevenue : 0.0;
    }
 
    // get all payments done by a user
    @Override
    public List<PaymentDTO> getPaymentsForUser(Long userId) {
        Session session = sessionFactory.openSession();   // changed
        List<Payment> payments = session.createQuery(
        		"SELECT p FROM Payment p " +
                        "JOIN p.registration r " +
                        "JOIN r.user u " +
                        "WHERE u.userId = :userId",
                    Payment.class
                )
                .setParameter("userId", userId)
                .getResultList();
        session.close();
        return payments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
 
    // get all payments for an event
    @Override
    public List<PaymentDTO> getPaymentsForEvent(Long eventId) {
        Session session = sessionFactory.openSession();  
        List<Payment> payments = session.createQuery(
        		
        		"SELECT p FROM Payment p " +
                        "JOIN p.registration r " +
                        "JOIN r.event e " +
                        "WHERE e.eventId = :eventId",
                    Payment.class
                )
                .setParameter("eventId", eventId)
                .getResultList();
        session.close();
        return payments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
 
    // helper method
    
    private PaymentDTO convertToDTO(Payment payment) {
        return new PaymentDTO(
            payment.getId(),
            payment.getRegistration().getId(),
            payment.getRegistration().getUser().getId(),
            payment.getRegistration().getUser().getUsername(),
            payment.getRegistration().getUser().getEmail(),
            payment.getRegistration().getEvent().getEventId(),
            payment.getAmount(),
            payment.getPaymentDate().toString(),
            payment.getPaymentStatus()
        );
    }
    
}
 