package com.soems.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.soems.entity.User;
import com.soems.service.UserService;
import com.soems.util.JwtUtil;

@Controller
@RequestMapping("/oauth2")
public class OAuth2Controller {

    @Autowired
    private UserService userService;
    @GetMapping("/success")
    public String oauth2Success(Authentication authentication, HttpServletResponse response, HttpServletRequest request) {
        
        // Extract authenticated OAuth2 user details (Google, GitHub, etc.)
        var oauthUser = (org.springframework.security.oauth2.core.user.DefaultOAuth2User) authentication.getPrincipal();
        String email = oauthUser.getAttribute("email");  // user's email from provider
        String name = oauthUser.getAttribute("name");    // user's name from provider

        // Check if user already exists in DB
        User user = userService.findByEmail(email);
        
        // If not found, register new user automatically
        if (user == null) {
            user = new User();
            user.setEmail(email);
            user.setUsername(name);
            user.setPassword("OAUTH2_USER"); // dummy password (not used for OAuth2 users)
            user.setRole(User.Role.USER);    // default role for new OAuth2 users
            
            userService.registerUser(user); // save user in DB
        }

        // Generate JWT token with user details
        String token = JwtUtil.generateToken(
            user.getId(),                 
            user.getEmail(),              
            user.getRole().name(),        
            user.getUsername()            
        );

        // Store JWT token in a cookie for client to use in requests
        Cookie cookie = new Cookie("JWT-TOKEN", token);
        cookie.setHttpOnly(false); // not HTTP-only 
        cookie.setPath(request.getContextPath().isEmpty() ? "/" : request.getContextPath()); // cookie path
        cookie.setMaxAge(60 * 60); // cookie validity: 1 hour
        response.addCookie(cookie);

        // Redirect user to dashboard after login success
        return "redirect:/dashboard";
    }
}
