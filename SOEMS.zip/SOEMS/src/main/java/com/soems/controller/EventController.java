package com.soems.controller;

import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.soems.dto.EventDTO;
import com.soems.entity.EventHistory;
import com.soems.entity.User;
import com.soems.service.EventService;
import com.soems.service.UserService;

@RestController // Marks this class as a REST controller → returns JSON responses directly
@RequestMapping("/events") // All endpoints in this controller start with "/events"
public class EventController {

    @Autowired 
    private EventService eventService;
    
    @Autowired 
    private UserService userService;

    // ====================== PUBLIC ENDPOINTS ======================

    // Get All Events
    @GetMapping
    public List<EventDTO> getAllEvents() {
        // Fetch and return all events as DTOs
        return eventService.getAllEvents();
    }
    
    // Get Upcoming Events
    @GetMapping("/upcoming")
    public List<EventDTO> getUpcomingEvents() {
        // Fetch events with future dates
        return eventService.getUpcomingEvents();
    }

    // Get Event by ID
    @GetMapping("/{id}")
    public EventDTO getEvent(@PathVariable Long id) {
        // Fetch event by its primary key (ID)
        return eventService.getEventById(id);
    }

    // Get Available Seats
    @GetMapping("/{eventId}/available-seats")
    public int getAvailableSeats(@PathVariable Long eventId) {
        // Calculate remaining seats by subtracting registered users from total capacity
        return eventService.getAvailableSeats(eventId);
    }

    // Search events with optional filters (location, amount, date, name)
    @GetMapping("/search")
    @ResponseBody
    public List<EventDTO> searchEvents(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) Double amount,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String eventName) {
        // Calls service layer method using dynamic criteria queries
        return eventService.searchEvents(location, amount, startDate, eventName);
    }
    
    // ====================== ADMIN ENDPOINTS ======================

    // Create Event 
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public String createEvent(@Valid @RequestBody EventDTO eventDTO) {
    	User admin = getLoggedInUser();
//    	event.setCreatedBy(admin);

        // Call service to save event and return confirmation message
        return eventService.createEvent(eventDTO, admin);
    }

    // Update Event 
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String updateEvent(@PathVariable Long id, @Valid @RequestBody EventDTO eventDTO) {

    	User admin = getLoggedInUser();
//    	event.setCreatedBy(admin);
    	eventDTO.setEventId(id);
        return eventService.updateEvent(eventDTO, admin);
    }

    // Delete Event 
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteEvent(@PathVariable Long id) {
    	User admin = getLoggedInUser();
       
        return eventService.deleteEvent(id, admin.getId());
    }
    
    // get all deleted events
    @GetMapping("/deleted")
    @PreAuthorize("hasRole('ADMIN')")
    public List<EventHistory> getAllDeletedEvents() {
        return eventService.getAllDeletedEvents();
    }
    
    // get all deleted events by admin
    @GetMapping("/deleted/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public List<EventHistory> getAllEventsDeletedByAdmin() {
    	User admin = getLoggedInUser();
        
        return eventService.getAllDeletedEventsByAdmin(admin.getId());
    }
    
    // Get events created by currently logged-in admin
    @GetMapping("/my-events")
    @PreAuthorize("hasRole('ADMIN')")
    public List<EventDTO> getMyEvents() {
    	User admin = getLoggedInUser();
        return eventService.getEventsByAdmin(admin.getId());
    }

    // ====================== HELPER METHOD ======================
    
    private User getLoggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName(); // username from UserDetails
        return userService.findByEmail(email);   // load full User entity
    }
}
