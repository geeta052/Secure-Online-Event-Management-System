package com.soems.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soems.dto.EventStatsDTO;
import com.soems.service.ReportService;

@RestController
@RequestMapping("/api/reports")
public class ReportController {

    @Autowired
    private ReportService reportService;

    // get statistic of event
    @GetMapping("/event-stats")
    @PreAuthorize("hasRole('ADMIN')")
    public List<EventStatsDTO> getEventStats(HttpServletRequest request) {
        Long adminId = (Long) request.getAttribute("userId"); 

        if (adminId == null) {
            throw new RuntimeException("Admin ID not found in request");
        }

        return reportService.getEventStats(adminId);
    }  
//    private void checkAdminAccess(HttpServletRequest request) {
//        String role = (String) request.getAttribute("role");
//        if (role == null || !role.equals("ADMIN")) {
//            throw new RuntimeException("Access Denied: Admin role required");
//        }
//    }
}

