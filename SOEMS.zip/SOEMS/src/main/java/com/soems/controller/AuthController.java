package com.soems.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.soems.dto.UserDTO;
import com.soems.entity.User;
import com.soems.service.UserService;
import com.soems.util.JwtUtil;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller // Marks this as a Spring MVC controller that can handle HTTP requests.
@RequestMapping("/auth") // All endpoints in this controller will start with "/auth"
public class AuthController {
	
	@Autowired // 
	private UserService userService;
	@Autowired
	private AuthenticationManager authenticationManager;
	
	// ===================== Register Page (GET) =====================
	@GetMapping("/register") 
	public String showRegisterPage() {
		// Returns the "register.jsp" 
		return "register";
	}
	
	// ===================== Login Page (GET) =====================
	@GetMapping("/login")
	public String showLoginPage() {
		// Returns the "login.jsp" 
		return "login";
	}
	
	// ===================== Register User (POST API) =====================
	@PostMapping("/register")
	@ResponseBody // Response will be JSON instead of a view page
	public ResponseEntity<?> register(@Valid @RequestBody UserDTO userDTO, BindingResult result) {
	    // Validate user input using @Valid (checks entity constraints)
	    if (result.hasErrors()) {
	        // If validation fails, collect all error messages
	        Map<String, String> errors = new HashMap<>();
	        result.getFieldErrors().forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
	        // Return 400 Bad Request with error details
	        return ResponseEntity.badRequest().body(errors);
	    }

	    // Call service layer to register user (saves user to DB)
	    String message = userService.registerUser(userDTO);
	    // Return success message
	    return ResponseEntity.ok(message);
	}

	// ===================== Login User (POST API) =====================
	@PostMapping("/login")
	@ResponseBody // Return JSON response
	public ResponseEntity<?> login(@RequestParam String email, @RequestParam String password,  HttpServletResponse response,
			HttpSession session, HttpServletRequest request) {

	    Authentication auth = authenticationManager.authenticate(
	            new UsernamePasswordAuthenticationToken(email, password)
	    );

	    User user = userService.findByEmail(email);
	    String token = JwtUtil.generateToken(user.getId(), user.getEmail(), user.getRole().name(), user.getUsername());
	    
	    // Create cookie to store JWT securely
        Cookie cookie = new Cookie("JWT-TOKEN", token);
        cookie.setHttpOnly(false); // Prevent JavaScript access (more secure)
        cookie.setPath(request.getContextPath().isEmpty() ? "/" : request.getContextPath()); // Cookie accessible across whole app
        cookie.setMaxAge(60 * 60); // Valid for 1 hour
        response.addCookie(cookie); // Add cookie to response

	    Map<String, String> result = new HashMap<>();
	    result.put("message", "Login successful");
	    result.put("role", user.getRole().name());
	    result.put("token", token);

	    return ResponseEntity.ok(result);
	}
	
	// ===================== Logout (GET) =====================
	@GetMapping("/logout")
	public String logout(HttpServletResponse response, HttpSession session, HttpServletRequest request) {
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
	    response.setHeader("Pragma", "no-cache");
	    response.setDateHeader("Expires", 0);
	    
	    // Remove JWT cookie by setting null value & expiry = 0
	    Cookie cookie = new Cookie("JWT-TOKEN", null);
	    cookie.setHttpOnly(false);
	    cookie.setPath(request.getContextPath().isEmpty() ? "/" : request.getContextPath()); 
	    cookie.setMaxAge(0); // Deletes cookie immediately
	    response.addCookie(cookie);
	    
	    // Redirect user to login page after logout
	    return "redirect:/auth/login";
	}
}
