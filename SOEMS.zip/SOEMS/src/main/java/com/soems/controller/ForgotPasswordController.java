package com.soems.controller;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.soems.entity.User;
import com.soems.service.EmailService;
import com.soems.service.UserService;

@Controller
public class ForgotPasswordController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;
    
    @GetMapping("/forgot-password")
    public String showForgotPasswordForm() {
        return "forgot-password-form";
    }

    // Step 1: Request reset
    @PostMapping("/forgot-password")
    @ResponseBody
    public ResponseEntity<?> forgotPassword(@RequestParam String email) {
        User user = userService.findByEmail(email);
        if (user == null) {
            return ResponseEntity.status(404).body(Map.of("error", "Email not found"));
        }

        String token = UUID.randomUUID().toString();
        user.setResetToken(token);
        userService.save(user);

        String appUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                .build()
                .toUriString();
        
        emailService.sendPasswordResetEmail(email, token, appUrl);

        return ResponseEntity.ok(Map.of("message", "Password reset link sent to email"));
    }

    // Step 2: Show reset form
    @GetMapping("/reset-password")
    public String showResetForm(@RequestParam String token, Model model) {
        User user = userService.findByResetToken(token);
        if (user == null) {
            model.addAttribute("error", "Invalid token");
            return "reset-password-error";
        }
        model.addAttribute("token", token);
        return "reset-password-form"; // JSP
    }

    // Step 3: Handle reset
    @PostMapping("/reset-password")
    public String resetPassword(@RequestParam String token,
                                @RequestParam String newPassword,
                                @RequestParam String confirmPassword,
                                Model model) {
        User user = userService.findByResetToken(token);
        if (user == null) {
            model.addAttribute("error", "Invalid or expired token");
            return "reset-password-error";
        }

        if (!newPassword.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match");
            model.addAttribute("token", token);
            return "reset-password-form";
        }

        String passwordPattern = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[!@#$%^&*(),.?\":{}|<>]).{8,}$";
        if (!newPassword.matches(passwordPattern)) {
            model.addAttribute("error", "Password must be at least 8 characters and contain " +
                    "an uppercase letter, a lowercase letter, a number, and a special character.");
            model.addAttribute("token", token);
            return "reset-password-form";
        }

        userService.updatePassword(user, newPassword);
        model.addAttribute("message", "Password reset successful. You can now log in.");
        return "login";
    }
}

