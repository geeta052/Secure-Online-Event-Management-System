package com.soems.controller;
 
import java.util.List;
import java.util.Map;

//import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.soems.dto.PaymentDTO;
import com.soems.entity.User;
import com.soems.service.PaymentService;
import com.soems.service.UserService;
 
@RestController
@RequestMapping("/api/payments")
public class PaymentController {
 
    @Autowired
    private PaymentService paymentService;
    
    @Autowired
    private UserService userService;
    
    /**
     * Make a payment after user registration.
     * Only accessible to authenticated users.
     */
    @PostMapping
    @PreAuthorize("hasRole('USER')")
    public PaymentDTO makePayment(@RequestBody PaymentDTO paymentDTO) {
        return paymentService.makePayment(paymentDTO);
    }
 
    /**
     * Get payment details by payment ID.
     * User must be authenticated.
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('USER')")
    public PaymentDTO getPayment(@PathVariable long id) {
        return paymentService.getPaymentById(id);
    }
 
    /**
     * Get all payments made for a specific registration ID.
     * User must be authenticated.
     */
    @GetMapping("/registration/{registrationId}")
    @PreAuthorize("hasRole('USER')")
    public List<PaymentDTO> getPaymentsByRegistration(@PathVariable long registrationId) {
        return paymentService.getPaymentsByRegistrationId(registrationId);
    }
    
    /**
     * Get total revenue report of an event.
     * Accessible only to admins.
     */
    @GetMapping("/event/{eventId}/revenue")
    @PreAuthorize("hasRole('ADMIN')")
    public double getEventRevenueReport(@PathVariable Long eventId) {
        return paymentService.getEventRevenueReport(eventId);
    }
    
    /**
     * Get all payments made by a specific user.
     * Accessible only to that user.
     */
    @GetMapping("/user/{userId}")
    @PreAuthorize("hasRole('USER')")
    public List<PaymentDTO> getPaymentsForUser(@PathVariable Long userId) {
        return paymentService.getPaymentsForUser(userId);
    }

    /**
     * Get all payments made for a specific event.
     * Accessible only to admins.
     */
    @GetMapping("/event/{eventId}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<PaymentDTO> getPaymentsForEvent(@PathVariable Long eventId) {
        return paymentService.getPaymentsForEvent(eventId);
    }
    
    /**
     * Create an order in Razorpay before making the payment.
     * Returns the order details in JSON format.
     */
    @PostMapping("/create-order")
    public ResponseEntity<Object> createOrder(@RequestParam int amount) {
        try {
            String order = paymentService.createRazorpayOrder(amount);
            return ResponseEntity.ok(new JSONObject(order).toMap());
        } catch (Exception e) {
            // Return JSON instead of plain text for better API response
            Map<String, String> errorResponse = Map.of("error", e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
 
    /**
     * Verify the payment signature returned from Razorpay.
     * Ensures the payment was not tampered with.
     */
    @PostMapping("/verify")
    public ResponseEntity<String> verifyPayment(@RequestBody Map<String, String> data) {
        boolean isValid = paymentService.verifySignature(data);
        if (isValid) {
            return ResponseEntity.ok("Payment verified successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid signature");
        }
    }
    
    /**
     * Verify the payment AND register the user for the event.
     * Requires a logged-in user (USER role).
     */
    @PostMapping("/verifyAndRegister")
    public ResponseEntity<String> verifyAndRegister(@RequestBody Map<String, String> data) {
        
        User user = getLoggedInUser();
        // If no logged-in user found in request attributes
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not logged in");
        }
        
        Long loggedInUserId = user.getId();

        // Attach the logged-in user ID to the payment data before verification
        data.put("userId", String.valueOf(loggedInUserId));
        
        String result = paymentService.verifyAndRegisterPayment(data);
        return ResponseEntity.ok(result);
    }

    // Helper Methods
    
    private User getLoggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName(); // username from UserDetails
        return userService.findByEmail(email);   // load full User entity
    }

}
