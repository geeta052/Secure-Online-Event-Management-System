package com.soems.controller;

import java.util.List;
//import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.soems.dto.RegistrationDTO;
import com.soems.entity.Registration;
import com.soems.service.RegistrationService;

@RestController
@RequestMapping("/registrations") // Base URL for all registration-related APIs
public class RegistrationController {

    @Autowired
    private RegistrationService registrationService; // Service layer dependency

    // ---------------- ADMIN ENDPOINTS ----------------

    // Create a new registration (ADMIN only)
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public String createRegistration(@RequestBody Registration registration) {
        return registrationService.createRegistration(registration);
    }

    // Get all registrations (ADMIN only)
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<RegistrationDTO> getAllRegistrations() {
        return registrationService.getAllRegistrations();
    }

    // Get a single registration by ID (ADMIN only)
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public RegistrationDTO getRegistration(@PathVariable Long id) {
        return registrationService.getRegistrationById(id);
    }

    // Update registration details (ADMIN only)
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String updateRegistration(@PathVariable Long id, @RequestBody Registration registration) {
        registration.setId(id); // set ID from path variable
        return registrationService.updateRegistration(registration);
    }

    // Delete a registration (ADMIN only)
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteRegistration(@PathVariable Long id) {
        return registrationService.deleteRegistration(id);
    }

    // Get all registrations for a specific event (ADMIN only)
    @GetMapping("/event/{eventId}")
    @PreAuthorize("hasRole('ADMIN')")
    public List<RegistrationDTO> getRegistrationsByEvent(@PathVariable Long eventId) {
        return registrationService.getRegistrationsForEvent(eventId);
    }

    // ---------------- USER ENDPOINTS ---------------------------------------------------

    // Get all registrations of a specific user (USER only, must match logged-in user)
    @GetMapping("/user/{userId}")
    @PreAuthorize("hasRole('USER')")
    public List<RegistrationDTO> getRegistrationsByUser(@PathVariable Long userId) {
        return registrationService.getRegistrationsForUser(userId);
    }

    // Register a user for an event (USER only)
    @PostMapping("/event/{eventId}/user/{userId}")
    @PreAuthorize("hasRole('USER')")
    public RegistrationDTO registerUser(@PathVariable Long eventId, @PathVariable Long userId) {
        return registrationService.registerUserForEvent(userId, eventId);
    }
        
    // Cancel a user’s registration (USER only, cancel their own)
    @DeleteMapping("/cancel/{eventId}/{userId}")
    @PreAuthorize("hasRole('USER')")
    public String cancelRegistration(@PathVariable Long eventId, @PathVariable Long userId) {
        boolean cancelled = registrationService.cancelRegistration(userId, eventId);
        return cancelled ? "Registration cancelled successfully." : "No registration found for this user and event.";
    }
}
