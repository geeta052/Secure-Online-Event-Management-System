package com.soems.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
		
	@GetMapping("/")
	public String redirectRoot() {
	    return "redirect:/home";
	}

	@GetMapping("/home")
	public String home() {
	    return "index";
	}

    
    @GetMapping("/admin")
    public String adminDashboard() {
        return "adminDashboard";
    }
    
    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }
    
    @GetMapping("/register")
    public String showRegisterPage() {
        return "register";   
    }
}
